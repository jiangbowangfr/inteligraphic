(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__bootstrapLoaded) { return; }
  NS.__bootstrapLoaded = true;

  NS.Bootstrap = {
    init: function (graph) {
      NS.install(graph);
      return NS;
    },

    openSelected: function (graph) {
      if (!graph || typeof graph.getSelectionCell !== 'function') {
        throw new Error('DftsConfig.Bootstrap.openSelected: graph.getSelectionCell is required');
      }
      var cell = graph.getSelectionCell();
      return NS.open(graph, cell);
    }
  };
})(this);
