(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__pageFunctionalLoaded) { return; }
  NS.__pageFunctionalLoaded = true;

  function makeRow(labelText, inputNode) {
    var row = document.createElement('div');
    var label = document.createElement('div');
    row.style.display = 'grid';
    row.style.gridTemplateColumns = '180px 1fr';
    row.style.gap = '8px';
    row.style.alignItems = 'center';
    row.style.marginBottom = '10px';
    label.textContent = labelText;
    label.style.fontWeight = 'bold';
    row.appendChild(label);
    row.appendChild(inputNode);
    return row;
  }

  NS.Registry.registerPage({
    id: 'functional_params',
    title: '参数配置',

    init: function (ctx, state) {
      state.runtime.functionalExtra = state.runtime.functionalExtra || {};
    },

    render: function (container, ctx, state) {
      var root = document.createElement('div');
      var bodyLabel = document.createElement('input');
      var instanceName = document.createElement('input');
      var notes = document.createElement('textarea');

      bodyLabel.type = 'text';
      bodyLabel.value = state.attrs.bodyLabel || state.symbolModel.title || ctx.dftsType || '';
      bodyLabel.onchange = function () {
        state.attrs.bodyLabel = bodyLabel.value;
        state.symbolModel.title = bodyLabel.value;
      };

      instanceName.type = 'text';
      instanceName.value = state.attrs.instanceName || state.symbolModel.instanceName || '';
      instanceName.onchange = function () {
        state.attrs.instanceName = instanceName.value;
        state.symbolModel.instanceName = instanceName.value;
      };

      notes.value = state.runtime.functionalExtra.notes || '';
      notes.rows = 6;
      notes.onchange = function () {
        state.runtime.functionalExtra.notes = notes.value;
      };

      root.appendChild(makeRow('模块标题', bodyLabel));
      root.appendChild(makeRow('实例名', instanceName));
      root.appendChild(makeRow('备注（仅运行时）', notes));

      container.innerHTML = '';
      container.appendChild(root);
    },

    validate: function (ctx, state) {
      var errors = [];
      if (!state.attrs.instanceName) {
        errors.push('参数配置：实例名不能为空。');
      }
      return errors;
    },

    buildPatch: function (ctx, state) {
      return {
        attrs: {
          bodyLabel: state.attrs.bodyLabel,
          instanceName: state.attrs.instanceName
        },
        symbolModel: state.symbolModel
      };
    }
  });
})(this);
