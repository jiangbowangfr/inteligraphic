(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__pageLayoutLoaded) { return; }
  NS.__pageLayoutLoaded = true;

  function ensurePins(state) {
    state.symbolModel = state.symbolModel || { title: '', instanceName: '', pins: [] };
    state.symbolModel.pins = state.symbolModel.pins || [];
  }

  function renderPreview(container, state) {
    var wrap = document.createElement('div');
    var title = document.createElement('div');
    var box = document.createElement('div');
    var pins = state.symbolModel.pins || [];
    var i;
    var line;
    title.style.fontWeight = 'bold';
    title.style.marginBottom = '8px';
    title.textContent = '布局预览（文本）';

    box.style.border = '1px solid #ccc';
    box.style.borderRadius = '6px';
    box.style.padding = '10px';
    box.style.background = '#fafafa';
    box.style.whiteSpace = 'pre-wrap';
    box.textContent = 'Title: ' + (state.symbolModel.title || state.attrs.bodyLabel || '') + '\n'
      + 'Instance: ' + (state.symbolModel.instanceName || state.attrs.instanceName || '') + '\n\n';

    for (i = 0; i < pins.length; i += 1) {
      line = '[' + (pins[i].side || 'west') + '] '
        + (pins[i].key || ('pin' + i))
        + ' | name=' + (pins[i].displayName || pins[i].name || pins[i].key || '')
        + ' | order=' + (pins[i].order != null ? pins[i].order : i)
        + ' | visible=' + (pins[i].visible === false ? '0' : '1');
      box.textContent += line + '\n';
    }

    wrap.appendChild(title);
    wrap.appendChild(box);
    container.appendChild(wrap);
  }

  NS.Registry.registerPage({
    id: 'layout',
    title: 'IP界面布局',

    init: function (ctx, state) {
      ensurePins(state);
    },

    render: function (container, ctx, state, api) {
      ensurePins(state);
      container.innerHTML = '';

      var shell = document.createElement('div');
      var left = document.createElement('div');
      var right = document.createElement('div');
      var header = document.createElement('div');
      var pins = state.symbolModel.pins || [];
      var i;

      shell.style.display = 'grid';
      shell.style.gridTemplateColumns = '1.3fr 0.7fr';
      shell.style.gap = '12px';

      left.style.border = '1px solid #ddd';
      left.style.borderRadius = '6px';
      left.style.padding = '10px';

      right.style.border = '1px solid #ddd';
      right.style.borderRadius = '6px';
      right.style.padding = '10px';
      right.style.background = '#fff';

      header.style.fontWeight = 'bold';
      header.style.marginBottom = '10px';
      header.textContent = '引脚布局编辑';

      left.appendChild(header);

      function rebuild() {
        api.refresh();
      }

      function addPinRow(pin, index) {
        var row = document.createElement('div');
        var name = document.createElement('div');
        var visibleWrap = document.createElement('label');
        var visible = document.createElement('input');
        var side = document.createElement('select');
        var order = document.createElement('input');
        var rename = document.createElement('input');
        var opt;
        var sides = ['west', 'east', 'north', 'south', 'hidden'];
        var j;

        row.style.display = 'grid';
        row.style.gridTemplateColumns = '1.1fr 1fr 1fr 1fr 1.2fr';
        row.style.gap = '8px';
        row.style.alignItems = 'center';
        row.style.marginBottom = '8px';
        row.style.paddingBottom = '8px';
        row.style.borderBottom = '1px dashed #ddd';

        name.textContent = pin.key || ('pin' + index);

        visible.type = 'checkbox';
        visible.checked = pin.visible !== false;
        visible.onchange = function () {
          pin.visible = !!visible.checked;
          rebuild();
        };
        visibleWrap.appendChild(visible);
        visibleWrap.appendChild(document.createTextNode(' visible'));

        for (j = 0; j < sides.length; j += 1) {
          opt = document.createElement('option');
          opt.value = sides[j];
          opt.textContent = sides[j];
          if ((pin.side || 'west') === sides[j]) {
            opt.selected = true;
          }
          side.appendChild(opt);
        }
        side.onchange = function () {
          pin.side = side.value;
          pin.visible = side.value !== 'hidden';
          rebuild();
        };

        order.type = 'number';
        order.value = pin.order != null ? pin.order : index;
        order.onchange = function () {
          pin.order = parseInt(order.value, 10) || 0;
          pins.sort(function (a, b) {
            return (a.order || 0) - (b.order || 0);
          });
          rebuild();
        };

        rename.type = 'text';
        rename.value = pin.displayName || pin.name || pin.key || '';
        rename.onchange = function () {
          pin.displayName = rename.value;
        };

        row.appendChild(name);
        row.appendChild(visibleWrap);
        row.appendChild(side);
        row.appendChild(order);
        row.appendChild(rename);
        left.appendChild(row);
      }

      for (i = 0; i < pins.length; i += 1) {
        addPinRow(pins[i], i);
      }

      if (!pins.length) {
        left.appendChild(document.createTextNode('当前没有 symbol pins，可在参数页或生成逻辑中补充。'));
      }

      renderPreview(right, state);

      shell.appendChild(left);
      shell.appendChild(right);
      container.appendChild(shell);
    },

    validate: function (ctx, state) {
      var errors = [];
      var pins = (state.symbolModel && state.symbolModel.pins) || [];
      var seen = {};
      var i;
      var key;
      for (i = 0; i < pins.length; i += 1) {
        key = pins[i] && pins[i].key;
        if (!key) {
          errors.push('布局页：存在缺少 key 的 pin。');
          continue;
        }
        if (seen[key]) {
          errors.push('布局页：pin key 重复：' + key);
        }
        seen[key] = true;
      }
      return errors;
    },

    buildPatch: function (ctx, state) {
      return {
        symbolModel: state.symbolModel
      };
    }
  });
})(this);
