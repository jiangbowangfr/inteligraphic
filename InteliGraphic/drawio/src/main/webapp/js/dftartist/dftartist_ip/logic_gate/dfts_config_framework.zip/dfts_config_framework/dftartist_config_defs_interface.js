(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__defsInterfaceLoaded) { return; }
  NS.__defsInterfaceLoaded = true;

  NS.Registry.registerCategoryConfig({
    id: 'interface',
    title: 'Interface Configuration',
    pages: ['interface_params', 'interface_naming', 'layout']
  });

  [
    'ssn_host_interface',
    'ssn_slave_interface',
    'bscan_host_interface',
    'bscan_slave_interface',
    'ijtag_host_interface',
    'ijtag_slave_interface',
    'bisr_host_interface',
    'bisr_slave_interface'
  ].forEach(function (typeId) {
    NS.Registry.registerTypeConfig({
      id: typeId,
      title: typeId + ' Configuration',
      category: 'interface',
      pages: ['interface_params', 'interface_naming', 'layout']
    });
  });
})(this);
