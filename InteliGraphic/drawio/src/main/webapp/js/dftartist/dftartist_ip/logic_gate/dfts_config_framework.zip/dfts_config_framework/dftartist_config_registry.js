(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__registryLoaded) { return; }
  NS.__registryLoaded = true;

  var pages = {};
  var categories = {};
  var types = {};

  function cloneArray(arr) {
    return arr ? arr.slice() : [];
  }

  function cloneObject(obj) {
    var out = {};
    var k;
    if (!obj) { return out; }
    for (k in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, k)) {
        out[k] = obj[k];
      }
    }
    return out;
  }

  NS.Registry = {
    registerPage: function (page) {
      if (!page || !page.id) {
        throw new Error('DftsConfig.registerPage: page.id is required');
      }
      pages[page.id] = page;
      return page;
    },

    getPage: function (id) {
      return pages[id] || null;
    },

    listPages: function () {
      return cloneObject(pages);
    },

    registerCategoryConfig: function (cfg) {
      if (!cfg || !cfg.id) {
        throw new Error('DftsConfig.registerCategoryConfig: cfg.id is required');
      }
      categories[cfg.id] = cfg;
      return cfg;
    },

    getCategoryConfig: function (id) {
      return categories[id] || null;
    },

    listCategoryConfigs: function () {
      return cloneObject(categories);
    },

    registerTypeConfig: function (cfg) {
      if (!cfg || !cfg.id) {
        throw new Error('DftsConfig.registerTypeConfig: cfg.id is required');
      }
      types[cfg.id] = cfg;
      return cfg;
    },

    getTypeConfig: function (id) {
      return types[id] || null;
    },

    listTypeConfigs: function () {
      return cloneObject(types);
    },

    resolveConfig: function (ctx) {
      var typeCfg = ctx && ctx.dftsType ? types[ctx.dftsType] : null;
      var catCfg = ctx && ctx.category ? categories[ctx.category] : null;
      var raw = typeCfg || catCfg || null;
      var source = typeCfg ? 'type' : (catCfg ? 'category' : '');
      var pageIds;
      var pageList = [];
      var i;
      var page;

      if (!raw) { return null; }

      pageIds = raw.pages && raw.pages.length ? cloneArray(raw.pages) : (catCfg && catCfg.pages ? cloneArray(catCfg.pages) : []);
      for (i = 0; i < pageIds.length; i += 1) {
        page = pages[pageIds[i]];
        if (!page) {
          throw new Error('DftsConfig.resolveConfig: page not found: ' + pageIds[i]);
        }
        pageList.push(page);
      }

      return {
        id: raw.id,
        source: source,
        title: raw.title || (ctx && ctx.dftsType ? ctx.dftsType : 'IP'),
        category: raw.category || (catCfg ? catCfg.id : (ctx ? ctx.category : '')),
        pages: pageList,
        raw: raw
      };
    }
  };
})(this);
