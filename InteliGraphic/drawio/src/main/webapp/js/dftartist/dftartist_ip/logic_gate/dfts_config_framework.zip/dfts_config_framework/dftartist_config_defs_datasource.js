(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__defsDatasourceLoaded) { return; }
  NS.__defsDatasourceLoaded = true;

  NS.Registry.registerCategoryConfig({
    id: 'datasource',
    title: 'Data Source Configuration',
    pages: ['datasource_params', 'floorplan', 'layout']
  });

  [
    'pattern_data_source',
    'scan_data_source',
    'external_data_source'
  ].forEach(function (typeId) {
    NS.Registry.registerTypeConfig({
      id: typeId,
      title: typeId + ' Configuration',
      category: 'datasource',
      pages: ['datasource_params', 'floorplan', 'layout']
    });
  });
})(this);
