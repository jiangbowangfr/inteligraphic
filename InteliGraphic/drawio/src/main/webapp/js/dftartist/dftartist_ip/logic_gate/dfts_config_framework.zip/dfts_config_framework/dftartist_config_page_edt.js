(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__pageEdtLoaded) { return; }
  NS.__pageEdtLoaded = true;

  function makeRow(labelText, inputNode) {
    var row = document.createElement('div');
    var label = document.createElement('div');
    row.style.display = 'grid';
    row.style.gridTemplateColumns = '220px 1fr';
    row.style.gap = '8px';
    row.style.alignItems = 'center';
    row.style.marginBottom = '10px';
    label.textContent = labelText;
    label.style.fontWeight = 'bold';
    row.appendChild(label);
    row.appendChild(inputNode);
    return row;
  }

  function ensureDefaults(state) {
    var attrs = state.attrs;
    if (!attrs.edtChannels) { attrs.edtChannels = '4'; }
    if (!attrs.edtChainsPerChannel) { attrs.edtChainsPerChannel = '16'; }
    if (!attrs.edtCompressorRatio) { attrs.edtCompressorRatio = '20'; }
    if (!attrs.edtMode) { attrs.edtMode = 'streaming'; }
  }

  function ensurePins(state) {
    state.symbolModel = state.symbolModel || { title: 'EDT', instanceName: '', pins: [] };
    state.symbolModel.title = state.attrs.bodyLabel || state.symbolModel.title || 'EDT';
    if (!state.symbolModel.pins || !state.symbolModel.pins.length) {
      state.symbolModel.pins = [
        { key: 'scan_in', displayName: 'scan_in', side: 'west', order: 0, visible: true },
        { key: 'scan_out', displayName: 'scan_out', side: 'east', order: 1, visible: true },
        { key: 'shift_clk', displayName: 'shift_clk', side: 'north', order: 2, visible: true },
        { key: 'update', displayName: 'update', side: 'south', order: 3, visible: true }
      ];
    }
  }

  NS.Registry.registerPage({
    id: 'edt_params',
    title: 'EDT参数',

    init: function (ctx, state) {
      ensureDefaults(state);
      ensurePins(state);
    },

    render: function (container, ctx, state) {
      ensureDefaults(state);
      ensurePins(state);

      var root = document.createElement('div');
      var bodyLabel = document.createElement('input');
      var instanceName = document.createElement('input');
      var channels = document.createElement('input');
      var chainsPerChannel = document.createElement('input');
      var ratio = document.createElement('input');
      var mode = document.createElement('select');
      var opt1 = document.createElement('option');
      var opt2 = document.createElement('option');

      bodyLabel.type = 'text';
      bodyLabel.value = state.attrs.bodyLabel || 'EDT';
      bodyLabel.onchange = function () {
        state.attrs.bodyLabel = bodyLabel.value;
        state.symbolModel.title = bodyLabel.value;
      };

      instanceName.type = 'text';
      instanceName.value = state.attrs.instanceName || '';
      instanceName.onchange = function () {
        state.attrs.instanceName = instanceName.value;
        state.symbolModel.instanceName = instanceName.value;
      };

      channels.type = 'number';
      channels.value = state.attrs.edtChannels;
      channels.onchange = function () {
        state.attrs.edtChannels = channels.value;
      };

      chainsPerChannel.type = 'number';
      chainsPerChannel.value = state.attrs.edtChainsPerChannel;
      chainsPerChannel.onchange = function () {
        state.attrs.edtChainsPerChannel = chainsPerChannel.value;
      };

      ratio.type = 'number';
      ratio.value = state.attrs.edtCompressorRatio;
      ratio.onchange = function () {
        state.attrs.edtCompressorRatio = ratio.value;
      };

      opt1.value = 'streaming';
      opt1.textContent = 'streaming';
      opt2.value = 'streaming_chain';
      opt2.textContent = 'streaming_chain';
      mode.appendChild(opt1);
      mode.appendChild(opt2);
      mode.value = state.attrs.edtMode;
      mode.onchange = function () {
        state.attrs.edtMode = mode.value;
      };

      root.appendChild(makeRow('模块标题', bodyLabel));
      root.appendChild(makeRow('实例名', instanceName));
      root.appendChild(makeRow('EDT Channels', channels));
      root.appendChild(makeRow('Chains / Channel', chainsPerChannel));
      root.appendChild(makeRow('Compressor Ratio', ratio));
      root.appendChild(makeRow('Mode', mode));

      container.innerHTML = '';
      container.appendChild(root);
    },

    validate: function (ctx, state) {
      var errors = [];
      if (!state.attrs.instanceName) {
        errors.push('EDT参数：实例名不能为空。');
      }
      if ((parseInt(state.attrs.edtChannels, 10) || 0) <= 0) {
        errors.push('EDT参数：Channels 必须大于 0。');
      }
      return errors;
    },

    buildPatch: function (ctx, state) {
      return {
        attrs: {
          bodyLabel: state.attrs.bodyLabel,
          instanceName: state.attrs.instanceName,
          edtChannels: state.attrs.edtChannels,
          edtChainsPerChannel: state.attrs.edtChainsPerChannel,
          edtCompressorRatio: state.attrs.edtCompressorRatio,
          edtMode: state.attrs.edtMode
        },
        symbolModel: state.symbolModel
      };
    }
  });
})(this);
