(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__modalLoaded) { return; }
  NS.__modalLoaded = true;

  function el(tag, style, text) {
    var node = document.createElement(tag);
    var k;
    if (style) {
      for (k in style) {
        if (Object.prototype.hasOwnProperty.call(style, k)) {
          node.style[k] = style[k];
        }
      }
    }
    if (text !== undefined && text !== null) {
      node.textContent = text;
    }
    return node;
  }

  function button(text, onClick, primary) {
    var btn = el('button', {
      minWidth: '84px',
      padding: '6px 12px',
      marginLeft: '8px',
      border: '1px solid #999',
      borderRadius: '4px',
      cursor: 'pointer',
      background: primary ? '#2d6cdf' : '#f2f2f2',
      color: primary ? '#fff' : '#222'
    }, text);
    btn.onclick = onClick;
    return btn;
  }

  function createModal(options) {
    var overlay = el('div', {
      position: 'fixed',
      left: '0',
      top: '0',
      right: '0',
      bottom: '0',
      background: 'rgba(0,0,0,0.25)',
      zIndex: '9999',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    });

    var panel = el('div', {
      width: options.width || '980px',
      height: options.height || '700px',
      background: '#fff',
      borderRadius: '8px',
      boxShadow: '0 12px 40px rgba(0,0,0,0.2)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
      fontFamily: 'Arial, sans-serif'
    });

    var header = el('div', {
      padding: '12px 16px',
      borderBottom: '1px solid #ddd',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    });

    var title = el('div', {
      fontSize: '18px',
      fontWeight: 'bold'
    }, options.title || 'Configuration');

    var closeBtn = el('button', {
      border: 'none',
      background: 'transparent',
      cursor: 'pointer',
      fontSize: '22px',
      lineHeight: '22px'
    }, '×');

    var tabBar = el('div', {
      display: 'flex',
      gap: '4px',
      padding: '10px 12px 0 12px',
      borderBottom: '1px solid #ddd',
      background: '#fafafa'
    });

    var body = el('div', {
      flex: '1',
      overflow: 'auto',
      padding: '12px'
    });

    var footer = el('div', {
      padding: '12px 16px',
      borderTop: '1px solid #ddd',
      display: 'flex',
      justifyContent: 'flex-end'
    });

    header.appendChild(title);
    header.appendChild(closeBtn);
    panel.appendChild(header);
    panel.appendChild(tabBar);
    panel.appendChild(body);
    panel.appendChild(footer);
    overlay.appendChild(panel);
    document.body.appendChild(overlay);

    var tabs = [];
    var activeId = '';

    function destroy() {
      if (overlay && overlay.parentNode) {
        overlay.parentNode.removeChild(overlay);
      }
    }

    function setTitle(text) {
      title.textContent = text || 'Configuration';
    }

    function setBody(nodeOrHtml) {
      body.innerHTML = '';
      if (typeof nodeOrHtml === 'string') {
        body.innerHTML = nodeOrHtml;
      } else if (nodeOrHtml) {
        body.appendChild(nodeOrHtml);
      }
    }

    function clearFooter() {
      footer.innerHTML = '';
    }

    function setFooterButtons(buttons) {
      var i;
      clearFooter();
      for (i = 0; i < buttons.length; i += 1) {
        footer.appendChild(buttons[i]);
      }
    }

    function setTabs(items, onSelect) {
      var i;
      var item;
      var btn;
      tabs = [];
      tabBar.innerHTML = '';

      function makeClick(id) {
        return function () {
          if (activeId === id) { return; }
          activeId = id;
          refreshTabs();
          onSelect(id);
        };
      }

      for (i = 0; i < items.length; i += 1) {
        item = items[i];
        btn = el('button', {
          padding: '8px 14px',
          border: '1px solid #ccc',
          borderBottom: 'none',
          borderTopLeftRadius: '6px',
          borderTopRightRadius: '6px',
          background: '#eee',
          cursor: 'pointer'
        }, item.title);
        btn.onclick = makeClick(item.id);
        tabs.push({ id: item.id, btn: btn });
        tabBar.appendChild(btn);
      }
      if (items.length) {
        activeId = items[0].id;
        refreshTabs();
      }
    }

    function refreshTabs() {
      var i;
      for (i = 0; i < tabs.length; i += 1) {
        tabs[i].btn.style.background = tabs[i].id === activeId ? '#fff' : '#eee';
        tabs[i].btn.style.fontWeight = tabs[i].id === activeId ? 'bold' : 'normal';
      }
    }

    closeBtn.onclick = function () {
      if (options.onClose) {
        options.onClose();
      } else {
        destroy();
      }
    };

    return {
      overlay: overlay,
      panel: panel,
      bodyEl: body,
      footerEl: footer,
      setTitle: setTitle,
      setBody: setBody,
      setTabs: setTabs,
      setFooterButtons: setFooterButtons,
      button: button,
      destroy: destroy
    };
  }

  NS.Modal = {
    create: createModal,
    el: el,
    button: button
  };
})(this);
