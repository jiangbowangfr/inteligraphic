(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__pageOccLoaded) { return; }
  NS.__pageOccLoaded = true;

  function makeRow(labelText, inputNode) {
    var row = document.createElement('div');
    var label = document.createElement('div');
    row.style.display = 'grid';
    row.style.gridTemplateColumns = '220px 1fr';
    row.style.gap = '8px';
    row.style.alignItems = 'center';
    row.style.marginBottom = '10px';
    label.textContent = labelText;
    label.style.fontWeight = 'bold';
    row.appendChild(label);
    row.appendChild(inputNode);
    return row;
  }

  function ensureDefaults(state) {
    if (!state.attrs.occDomains) { state.attrs.occDomains = '1'; }
    if (!state.attrs.occShiftClock) { state.attrs.occShiftClock = 'shift_clk'; }
    if (!state.attrs.occCaptureClock) { state.attrs.occCaptureClock = 'capture_clk'; }
    if (!state.attrs.occBypass) { state.attrs.occBypass = '0'; }
    state.symbolModel = state.symbolModel || { title: 'OCC', instanceName: '', pins: [] };
    if (!state.symbolModel.pins || !state.symbolModel.pins.length) {
      state.symbolModel.pins = [
        { key: 'shift_clk', displayName: 'shift_clk', side: 'west', order: 0, visible: true },
        { key: 'capture_clk', displayName: 'capture_clk', side: 'west', order: 1, visible: true },
        { key: 'occ_out', displayName: 'occ_out', side: 'east', order: 2, visible: true }
      ];
    }
  }

  NS.Registry.registerPage({
    id: 'occ_params',
    title: 'OCC参数',

    init: function (ctx, state) {
      ensureDefaults(state);
    },

    render: function (container, ctx, state) {
      ensureDefaults(state);
      var root = document.createElement('div');
      var instanceName = document.createElement('input');
      var domains = document.createElement('input');
      var shiftClock = document.createElement('input');
      var captureClock = document.createElement('input');
      var bypass = document.createElement('input');

      instanceName.type = 'text';
      instanceName.value = state.attrs.instanceName || '';
      instanceName.onchange = function () {
        state.attrs.instanceName = instanceName.value;
        state.symbolModel.instanceName = instanceName.value;
      };

      domains.type = 'number';
      domains.value = state.attrs.occDomains;
      domains.onchange = function () {
        state.attrs.occDomains = domains.value;
      };

      shiftClock.type = 'text';
      shiftClock.value = state.attrs.occShiftClock;
      shiftClock.onchange = function () {
        state.attrs.occShiftClock = shiftClock.value;
      };

      captureClock.type = 'text';
      captureClock.value = state.attrs.occCaptureClock;
      captureClock.onchange = function () {
        state.attrs.occCaptureClock = captureClock.value;
      };

      bypass.type = 'checkbox';
      bypass.checked = state.attrs.occBypass === '1';
      bypass.onchange = function () {
        state.attrs.occBypass = bypass.checked ? '1' : '0';
      };

      root.appendChild(makeRow('实例名', instanceName));
      root.appendChild(makeRow('Clock Domains', domains));
      root.appendChild(makeRow('Shift Clock Name', shiftClock));
      root.appendChild(makeRow('Capture Clock Name', captureClock));
      root.appendChild(makeRow('Enable Bypass', bypass));

      container.innerHTML = '';
      container.appendChild(root);
    },

    validate: function (ctx, state) {
      var errors = [];
      if (!state.attrs.instanceName) {
        errors.push('OCC参数：实例名不能为空。');
      }
      return errors;
    },

    buildPatch: function (ctx, state) {
      return {
        attrs: {
          instanceName: state.attrs.instanceName,
          occDomains: state.attrs.occDomains,
          occShiftClock: state.attrs.occShiftClock,
          occCaptureClock: state.attrs.occCaptureClock,
          occBypass: state.attrs.occBypass
        },
        symbolModel: state.symbolModel
      };
    }
  });
})(this);
