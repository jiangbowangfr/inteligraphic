(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__pageIfNamingLoaded) { return; }
  NS.__pageIfNamingLoaded = true;

  NS.Registry.registerPage({
    id: 'interface_naming',
    title: '命名预览',

    render: function (container, ctx, state) {
      var pins = (state.symbolModel && state.symbolModel.pins) || [];
      var table = document.createElement('table');
      var thead = document.createElement('thead');
      var tbody = document.createElement('tbody');
      var trh = document.createElement('tr');
      var headers = ['Pin Key', 'Display Name', 'Side'];
      var i;
      var j;
      var cell;
      var tr;
      var td;

      table.style.width = '100%';
      table.style.borderCollapse = 'collapse';

      for (i = 0; i < headers.length; i += 1) {
        cell = document.createElement('th');
        cell.textContent = headers[i];
        cell.style.textAlign = 'left';
        cell.style.borderBottom = '1px solid #ddd';
        cell.style.padding = '6px';
        trh.appendChild(cell);
      }
      thead.appendChild(trh);

      for (j = 0; j < pins.length; j += 1) {
        tr = document.createElement('tr');

        td = document.createElement('td');
        td.textContent = pins[j].key || '';
        td.style.padding = '6px';
        tr.appendChild(td);

        td = document.createElement('td');
        td.textContent = pins[j].displayName || pins[j].name || '';
        td.style.padding = '6px';
        tr.appendChild(td);

        td = document.createElement('td');
        td.textContent = pins[j].side || '';
        td.style.padding = '6px';
        tr.appendChild(td);

        tbody.appendChild(tr);
      }

      table.appendChild(thead);
      table.appendChild(tbody);
      container.innerHTML = '';
      container.appendChild(table);
    },

    buildPatch: function () {
      return null;
    }
  });
})(this);
