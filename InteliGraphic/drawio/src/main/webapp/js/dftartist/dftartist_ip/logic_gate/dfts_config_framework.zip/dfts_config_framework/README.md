# DFTs Config Framework (Pure JS)

这是一套**不考虑兼容性**的统一配置框架骨架，目标是：

- 一个统一入口：`DftsConfig.open(graph, cell)`
- 一个统一弹窗宿主：多页签 + 统一保存
- 按 `dftsIP_type / dftsIP_category` 路由
- 每个 tab 是一个独立 Page Plugin
- 页面只改 draft state，不直接写 graph
- 保存时统一合并 patch，一次性提交

## 文件说明

- `dftartist_config_registry.js`：页面 / 类型 / 类别注册表
- `dftartist_config_state.js`：读取 cell style / attrs，构建 context + draft state
- `dftartist_config_modal.js`：通用原生 DOM 弹窗
- `dftartist_config_apply.js`：统一保存逻辑
- `dftartist_config_core.js`：统一入口 + 双击安装
- `dftartist_config_bootstrap.js`：初始化辅助

### 通用页
- `dftartist_config_page_layout.js`
- `dftartist_config_page_preview.js`

### functional 页
- `dftartist_config_page_functional.js`
- `dftartist_config_page_edt.js`
- `dftartist_config_page_occ.js`

### interface 页
- `dftartist_config_page_interface.js`
- `dftartist_config_page_if_naming.js`

### datasource 页
- `dftartist_config_page_datasource.js`
- `dftartist_config_page_floorplan.js`

### 类型注册
- `dftartist_config_defs_functional.js`
- `dftartist_config_defs_interface.js`
- `dftartist_config_defs_datasource.js`

## 建议加载顺序

1. registry
2. state
3. modal
4. apply
5. pages...
6. defs...
7. core
8. bootstrap

## 最小接入

```js
DftsConfig.Bootstrap.init(graph);
```

之后双击带有 `dftsIP_type` 的 body cell，就会打开配置。

也可以手动打开：

```js
DftsConfig.open(graph, cell);
```

## 注意

这是一套“新框架骨架”，为了便于直接起步，我没有做对旧系统的兼容桥接。
如果你要接回你现有的旧 `DftsIP` 构造 / Symbol / Floorplan 细节，建议再按你实际项目做二次收口。
