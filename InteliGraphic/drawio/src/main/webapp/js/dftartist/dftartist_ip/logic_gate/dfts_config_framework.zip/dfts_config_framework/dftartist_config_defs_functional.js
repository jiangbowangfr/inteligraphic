(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__defsFunctionalLoaded) { return; }
  NS.__defsFunctionalLoaded = true;

  NS.Registry.registerCategoryConfig({
    id: 'functional',
    title: 'Functional IP Configuration',
    pages: ['functional_params', 'layout', 'preview']
  });

  NS.Registry.registerTypeConfig({
    id: 'edt',
    title: 'EDT Configuration',
    category: 'functional',
    pages: ['edt_params', 'layout', 'preview']
  });

  NS.Registry.registerTypeConfig({
    id: 'occ',
    title: 'OCC Configuration',
    category: 'functional',
    pages: ['occ_params', 'layout', 'preview']
  });

  [
    'tap',
    'tdri',
    'stap',
    'memory_bisr_controller',
    'ssn_fifo',
    'ssn_scan_host',
    'ssn_pipeline',
    'ssn_multiplexer',
    'ssn_output_pipeline',
    'ssn_bus_frequency_divider',
    'ssn_bus_frequency_multiplier'
  ].forEach(function (typeId) {
    NS.Registry.registerTypeConfig({
      id: typeId,
      title: typeId + ' Configuration',
      category: 'functional',
      pages: ['functional_params', 'layout', 'preview']
    });
  });
})(this);
