(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__applyLoaded) { return; }
  NS.__applyLoaded = true;

  function cloneDeep(input) {
    return NS.State && NS.State.cloneDeep ? NS.State.cloneDeep(input) : JSON.parse(JSON.stringify(input));
  }

  function mergePatches(patches) {
    var out = { attrs: {}, symbolModel: null, effects: [] };
    var i;
    var p;
    var k;
    for (i = 0; i < patches.length; i += 1) {
      p = patches[i];
      if (!p) { continue; }
      if (p.attrs) {
        for (k in p.attrs) {
          if (Object.prototype.hasOwnProperty.call(p.attrs, k)) {
            out.attrs[k] = p.attrs[k];
          }
        }
      }
      if (p.symbolModel) {
        out.symbolModel = cloneDeep(p.symbolModel);
      }
      if (p.effects && p.effects.length) {
        out.effects = out.effects.concat(p.effects);
      }
    }
    return out;
  }

  function applyAttrs(ctx, attrs) {
    var k;
    var body = ctx.body;
    var graph = ctx.graph;
    if (!attrs) { return; }

    for (k in attrs) {
      if (Object.prototype.hasOwnProperty.call(attrs, k)) {
        NS.State.writeAttr(graph, body, k, attrs[k]);
      }
    }

    if (attrs.bodyLabel !== undefined) {
      NS.State.writeStyleValue(body, 'dftsIP_bodyLabel', attrs.bodyLabel || '');
    }
  }

  function applySymbolModel(ctx, model) {
    var body = ctx.body;
    var graph = ctx.graph;
    var encoded;
    if (!model) { return; }

    body.__dftsSymbolModel = cloneDeep(model);
    encoded = encodeURIComponent(JSON.stringify(model));
    NS.State.writeStyleValue(body, 'dftsIP_symbolModel', encoded);

    if (global.DftsIP && global.DftsIP.Symbol) {
      if (typeof global.DftsIP.Symbol.setModel === 'function') {
        try {
          global.DftsIP.Symbol.setModel(body, cloneDeep(model));
        } catch (err) {}
      }
      if (typeof global.DftsIP.Symbol.relayout === 'function') {
        try {
          global.DftsIP.Symbol.relayout(graph, body);
        } catch (err) {}
      }
    }

    if (graph && typeof graph.refresh === 'function') {
      try { graph.refresh(body); } catch (err2) {}
    }
  }

  function runEffects(ctx, effects, mergedPatch) {
    var i;
    if (!effects) { return; }
    for (i = 0; i < effects.length; i += 1) {
      try {
        if (typeof effects[i] === 'function') {
          effects[i](ctx, mergedPatch);
        }
      } catch (err) {
        if (global.console && console.warn) {
          console.warn('[DftsConfig] effect failed:', err);
        }
      }
    }
  }

  function applyMergedPatch(ctx, mergedPatch) {
    var model = ctx.graph && typeof ctx.graph.getModel === 'function' ? ctx.graph.getModel() : null;
    var inTxn = false;

    if (model && typeof model.beginUpdate === 'function') {
      model.beginUpdate();
      inTxn = true;
    }

    try {
      applyAttrs(ctx, mergedPatch.attrs);
      applySymbolModel(ctx, mergedPatch.symbolModel);
      runEffects(ctx, mergedPatch.effects, mergedPatch);
    } finally {
      if (inTxn && typeof model.endUpdate === 'function') {
        model.endUpdate();
      }
    }
  }

  NS.Apply = {
    mergePatches: mergePatches,
    applyMergedPatch: applyMergedPatch,
    applyAttrs: applyAttrs,
    applySymbolModel: applySymbolModel
  };
})(this);
