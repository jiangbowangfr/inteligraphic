(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__pagePreviewLoaded) { return; }
  NS.__pagePreviewLoaded = true;

  function pretty(obj) {
    try {
      return JSON.stringify(obj, null, 2);
    } catch (err) {
      return String(obj);
    }
  }

  NS.Registry.registerPage({
    id: 'preview',
    title: '预览',

    render: function (container, ctx, state) {
      var shell = document.createElement('div');
      var sec1 = document.createElement('div');
      var sec2 = document.createElement('div');
      var pre1 = document.createElement('pre');
      var pre2 = document.createElement('pre');

      shell.style.display = 'grid';
      shell.style.gridTemplateColumns = '1fr 1fr';
      shell.style.gap = '12px';

      sec1.style.border = '1px solid #ddd';
      sec1.style.borderRadius = '6px';
      sec1.style.padding = '10px';

      sec2.style.border = '1px solid #ddd';
      sec2.style.borderRadius = '6px';
      sec2.style.padding = '10px';

      sec1.appendChild(document.createTextNode('参数预览'));
      pre1.textContent = pretty(state.attrs);
      pre1.style.marginTop = '8px';

      sec2.appendChild(document.createTextNode('布局模型预览'));
      pre2.textContent = pretty(state.symbolModel);
      pre2.style.marginTop = '8px';

      sec1.appendChild(pre1);
      sec2.appendChild(pre2);
      shell.appendChild(sec1);
      shell.appendChild(sec2);
      container.innerHTML = '';
      container.appendChild(shell);
    },

    buildPatch: function () {
      return null;
    }
  });
})(this);
