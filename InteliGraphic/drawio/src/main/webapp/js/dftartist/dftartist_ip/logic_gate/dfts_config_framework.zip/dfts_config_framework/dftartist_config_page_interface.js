(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__pageInterfaceLoaded) { return; }
  NS.__pageInterfaceLoaded = true;

  function makeRow(labelText, inputNode) {
    var row = document.createElement('div');
    var label = document.createElement('div');
    row.style.display = 'grid';
    row.style.gridTemplateColumns = '220px 1fr';
    row.style.gap = '8px';
    row.style.alignItems = 'center';
    row.style.marginBottom = '10px';
    label.textContent = labelText;
    label.style.fontWeight = 'bold';
    row.appendChild(label);
    row.appendChild(inputNode);
    return row;
  }

  function updatePinNamesFromAttrs(state) {
    var pins = (state.symbolModel && state.symbolModel.pins) || [];
    var role = state.attrs.role || 'host';
    var pinLabel = state.attrs.pinLabel || 'sig';
    var busWidth = state.attrs.busWidth || '1';
    var pdg = state.attrs.pdg || 'PDG0';
    var i;
    for (i = 0; i < pins.length; i += 1) {
      pins[i].displayName = pinLabel + '_' + (pins[i].key || ('pin' + i)) + '_' + role + '_' + pdg + '_w' + busWidth;
    }
  }

  function ensureDefaults(state, ctx) {
    state.attrs.role = state.attrs.role || ((ctx.dftsType || '').indexOf('slave') >= 0 ? 'slave' : 'host');
    state.attrs.pdg = state.attrs.pdg || 'PDG0';
    state.attrs.pinLabel = state.attrs.pinLabel || 'sig';
    state.attrs.busWidth = state.attrs.busWidth || '1';
    state.symbolModel = state.symbolModel || { title: ctx.dftsType || 'Interface', instanceName: '', pins: [] };
    if (!state.symbolModel.pins || !state.symbolModel.pins.length) {
      state.symbolModel.pins = [
        { key: 'clock', side: 'west', order: 0, visible: true },
        { key: 'data_in', side: 'west', order: 1, visible: true },
        { key: 'data_out', side: 'east', order: 2, visible: true }
      ];
    }
    updatePinNamesFromAttrs(state);
  }

  NS.Registry.registerPage({
    id: 'interface_params',
    title: '接口参数',

    init: function (ctx, state) {
      ensureDefaults(state, ctx);
    },

    render: function (container, ctx, state, api) {
      ensureDefaults(state, ctx);
      var root = document.createElement('div');
      var role = document.createElement('select');
      var opt1 = document.createElement('option');
      var opt2 = document.createElement('option');
      var pdg = document.createElement('input');
      var pinLabel = document.createElement('input');
      var busWidth = document.createElement('input');

      opt1.value = 'host';
      opt1.textContent = 'host';
      opt2.value = 'slave';
      opt2.textContent = 'slave';
      role.appendChild(opt1);
      role.appendChild(opt2);
      role.value = state.attrs.role;
      role.onchange = function () {
        state.attrs.role = role.value;
        updatePinNamesFromAttrs(state);
        api.refresh();
      };

      pdg.type = 'text';
      pdg.value = state.attrs.pdg;
      pdg.onchange = function () {
        state.attrs.pdg = pdg.value;
        updatePinNamesFromAttrs(state);
        api.refresh();
      };

      pinLabel.type = 'text';
      pinLabel.value = state.attrs.pinLabel;
      pinLabel.onchange = function () {
        state.attrs.pinLabel = pinLabel.value;
        updatePinNamesFromAttrs(state);
        api.refresh();
      };

      busWidth.type = 'number';
      busWidth.value = state.attrs.busWidth;
      busWidth.onchange = function () {
        state.attrs.busWidth = busWidth.value;
        updatePinNamesFromAttrs(state);
        api.refresh();
      };

      root.appendChild(makeRow('角色', role));
      root.appendChild(makeRow('PDG', pdg));
      root.appendChild(makeRow('Pin Label Prefix', pinLabel));
      root.appendChild(makeRow('Bus Width', busWidth));

      container.innerHTML = '';
      container.appendChild(root);
    },

    validate: function (ctx, state) {
      var errors = [];
      if ((parseInt(state.attrs.busWidth, 10) || 0) <= 0) {
        errors.push('接口参数：Bus Width 必须大于 0。');
      }
      return errors;
    },

    buildPatch: function (ctx, state) {
      return {
        attrs: {
          role: state.attrs.role,
          pdg: state.attrs.pdg,
          pinLabel: state.attrs.pinLabel,
          busWidth: state.attrs.busWidth
        },
        symbolModel: state.symbolModel,
        effects: [
          function (ctx2) {
            if (ctx2.graph && typeof ctx2.graph.refresh === 'function') {
              try { ctx2.graph.refresh(ctx2.body); } catch (err) {}
            }
          }
        ]
      };
    }
  });
})(this);
