(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__pageDatasourceLoaded) { return; }
  NS.__pageDatasourceLoaded = true;

  function makeRow(labelText, inputNode) {
    var row = document.createElement('div');
    var label = document.createElement('div');
    row.style.display = 'grid';
    row.style.gridTemplateColumns = '220px 1fr';
    row.style.gap = '8px';
    row.style.alignItems = 'center';
    row.style.marginBottom = '10px';
    label.textContent = labelText;
    label.style.fontWeight = 'bold';
    row.appendChild(label);
    row.appendChild(inputNode);
    return row;
  }

  function ensureDefaults(state) {
    state.attrs.sourceType = state.attrs.sourceType || 'pattern';
    state.attrs.patternSet = state.attrs.patternSet || 'default_set';
    if (!state.attrs.autoStart) { state.attrs.autoStart = '0'; }
    state.symbolModel = state.symbolModel || { title: 'DataSource', instanceName: '', pins: [] };
    if (!state.symbolModel.pins || !state.symbolModel.pins.length) {
      state.symbolModel.pins = [
        { key: 'data_out', displayName: 'data_out', side: 'east', order: 0, visible: true }
      ];
    }
  }

  NS.Registry.registerPage({
    id: 'datasource_params',
    title: '数据源参数',

    init: function (ctx, state) {
      ensureDefaults(state);
    },

    render: function (container, ctx, state) {
      ensureDefaults(state);
      var root = document.createElement('div');
      var sourceType = document.createElement('select');
      var opt1 = document.createElement('option');
      var opt2 = document.createElement('option');
      var opt3 = document.createElement('option');
      var patternSet = document.createElement('input');
      var autoStart = document.createElement('input');

      opt1.value = 'pattern';
      opt1.textContent = 'pattern';
      opt2.value = 'file';
      opt2.textContent = 'file';
      opt3.value = 'external';
      opt3.textContent = 'external';
      sourceType.appendChild(opt1);
      sourceType.appendChild(opt2);
      sourceType.appendChild(opt3);
      sourceType.value = state.attrs.sourceType;
      sourceType.onchange = function () {
        state.attrs.sourceType = sourceType.value;
      };

      patternSet.type = 'text';
      patternSet.value = state.attrs.patternSet;
      patternSet.onchange = function () {
        state.attrs.patternSet = patternSet.value;
      };

      autoStart.type = 'checkbox';
      autoStart.checked = state.attrs.autoStart === '1';
      autoStart.onchange = function () {
        state.attrs.autoStart = autoStart.checked ? '1' : '0';
      };

      root.appendChild(makeRow('Source Type', sourceType));
      root.appendChild(makeRow('Pattern Set', patternSet));
      root.appendChild(makeRow('Auto Start', autoStart));

      container.innerHTML = '';
      container.appendChild(root);
    },

    buildPatch: function (ctx, state) {
      return {
        attrs: {
          sourceType: state.attrs.sourceType,
          patternSet: state.attrs.patternSet,
          autoStart: state.attrs.autoStart
        },
        symbolModel: state.symbolModel
      };
    }
  });
})(this);
