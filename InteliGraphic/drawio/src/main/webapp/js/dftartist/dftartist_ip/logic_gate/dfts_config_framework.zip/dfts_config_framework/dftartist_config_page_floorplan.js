(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__pageFloorplanLoaded) { return; }
  NS.__pageFloorplanLoaded = true;

  function makeRow(labelText, inputNode) {
    var row = document.createElement('div');
    var label = document.createElement('div');
    row.style.display = 'grid';
    row.style.gridTemplateColumns = '220px 1fr';
    row.style.gap = '8px';
    row.style.alignItems = 'center';
    row.style.marginBottom = '10px';
    label.textContent = labelText;
    label.style.fontWeight = 'bold';
    row.appendChild(label);
    row.appendChild(inputNode);
    return row;
  }

  function ensureDefaults(state) {
    if (!state.attrs.floorplanEnabled) { state.attrs.floorplanEnabled = '1'; }
    if (!state.attrs.floorplanAnchorPolicy) { state.attrs.floorplanAnchorPolicy = 'source'; }
    if (!state.attrs.floorplanStartPinKey) {
      state.attrs.floorplanStartPinKey = (state.symbolModel && state.symbolModel.pins && state.symbolModel.pins[0] && state.symbolModel.pins[0].key) || '';
    }
  }

  NS.Registry.registerPage({
    id: 'floorplan',
    title: 'Floorplan',

    init: function (ctx, state) {
      ensureDefaults(state);
    },

    render: function (container, ctx, state) {
      ensureDefaults(state);

      var root = document.createElement('div');
      var enabled = document.createElement('input');
      var anchorPolicy = document.createElement('select');
      var opt1 = document.createElement('option');
      var opt2 = document.createElement('option');
      var pinSelect = document.createElement('select');
      var pins = (state.symbolModel && state.symbolModel.pins) || [];
      var i;
      var opt;

      enabled.type = 'checkbox';
      enabled.checked = state.attrs.floorplanEnabled === '1';
      enabled.onchange = function () {
        state.attrs.floorplanEnabled = enabled.checked ? '1' : '0';
      };

      opt1.value = 'source';
      opt1.textContent = 'source';
      opt2.value = 'target';
      opt2.textContent = 'target';
      anchorPolicy.appendChild(opt1);
      anchorPolicy.appendChild(opt2);
      anchorPolicy.value = state.attrs.floorplanAnchorPolicy;
      anchorPolicy.onchange = function () {
        state.attrs.floorplanAnchorPolicy = anchorPolicy.value;
      };

      for (i = 0; i < pins.length; i += 1) {
        opt = document.createElement('option');
        opt.value = pins[i].key || '';
        opt.textContent = pins[i].key || ('pin' + i);
        pinSelect.appendChild(opt);
      }
      pinSelect.value = state.attrs.floorplanStartPinKey || '';
      pinSelect.onchange = function () {
        state.attrs.floorplanStartPinKey = pinSelect.value;
      };

      root.appendChild(makeRow('Enable Floorplan Start', enabled));
      root.appendChild(makeRow('Anchor Policy', anchorPolicy));
      root.appendChild(makeRow('Start Pin Key', pinSelect));

      container.innerHTML = '';
      container.appendChild(root);
    },

    buildPatch: function (ctx, state) {
      return {
        attrs: {
          floorplanEnabled: state.attrs.floorplanEnabled,
          floorplanAnchorPolicy: state.attrs.floorplanAnchorPolicy,
          floorplanStartPinKey: state.attrs.floorplanStartPinKey
        },
        effects: [
          function (ctx2) {
            var body = ctx2.body;
            NS.State.writeStyleValue(body, 'floorplan', state.attrs.floorplanEnabled === '1' ? '1' : '0');
            NS.State.writeStyleValue(body, 'dftsIP_floorplanAnchorSide', state.attrs.floorplanAnchorPolicy || 'source');
            if (ctx2.graph && typeof ctx2.graph.refresh === 'function') {
              try { ctx2.graph.refresh(body); } catch (err) {}
            }
          }
        ]
      };
    }
  });
})(this);
