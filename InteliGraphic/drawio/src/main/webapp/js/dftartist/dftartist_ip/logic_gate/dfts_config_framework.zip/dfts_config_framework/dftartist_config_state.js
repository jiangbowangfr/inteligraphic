(function (global) {
  var NS = global.DftsConfig = global.DftsConfig || {};
  if (NS.__stateLoaded) { return; }
  NS.__stateLoaded = true;

  function toStringValue(v) {
    return v == null ? '' : String(v);
  }

  function parseStyleMap(style) {
    var map = {};
    var str = toStringValue(style);
    var parts = str.split(';');
    var i;
    var item;
    var idx;
    var key;
    var val;
    for (i = 0; i < parts.length; i += 1) {
      item = parts[i];
      if (!item) { continue; }
      idx = item.indexOf('=');
      if (idx < 0) {
        map[item] = '1';
      } else {
        key = item.substring(0, idx);
        val = item.substring(idx + 1);
        map[key] = val;
      }
    }
    return map;
  }

  function encodeStyleMap(map) {
    var out = [];
    var k;
    for (k in map) {
      if (Object.prototype.hasOwnProperty.call(map, k) && map[k] !== null && map[k] !== undefined && map[k] !== '') {
        out.push(k + '=' + map[k]);
      }
    }
    return out.join(';');
  }

  function readStyleValue(cell, key) {
    var map;
    if (!cell) { return ''; }
    map = parseStyleMap(cell.style || '');
    return map[key] || '';
  }

  function writeStyleValue(cell, key, val) {
    var map;
    if (!cell) { return; }
    map = parseStyleMap(cell.style || '');
    if (val === null || val === undefined || val === '') {
      delete map[key];
    } else {
      map[key] = String(val);
    }
    cell.style = encodeStyleMap(map);
  }

  function cloneDeep(input) {
    if (input === null || input === undefined) { return input; }
    return JSON.parse(JSON.stringify(input));
  }

  function getXmlAttr(cell, name) {
    var value = cell ? cell.value : null;
    if (value && typeof value.getAttribute === 'function') {
      return value.getAttribute(name);
    }
    return null;
  }

  function setXmlAttr(cell, name, val) {
    var value = cell ? cell.value : null;
    if (value && typeof value.setAttribute === 'function') {
      value.setAttribute(name, val == null ? '' : String(val));
    }
  }

  function readAttr(graph, cell, name) {
    if (!cell || !name) { return ''; }
    if (graph && typeof graph.getAttributeForCell === 'function') {
      try {
        return graph.getAttributeForCell(cell, name, '');
      } catch (err) {}
    }
    return getXmlAttr(cell, name) || '';
  }

  function writeAttr(graph, cell, name, value) {
    if (!cell || !name) { return; }
    if (graph && typeof graph.setAttributeForCell === 'function') {
      try {
        graph.setAttributeForCell(cell, name, value == null ? '' : String(value));
        return;
      } catch (err) {}
    }
    setXmlAttr(cell, name, value);
  }

  function tryParseJson(text, fallback) {
    if (!text) { return fallback; }
    try {
      return JSON.parse(text);
    } catch (err) {
      return fallback;
    }
  }

  function guessDefaultSymbolModel(body, ctx) {
    var title = readAttr(ctx.graph, body, 'bodyLabel') || readStyleValue(body, 'dftsIP_bodyLabel') || ctx.dftsType || 'IP';
    var instanceName = readAttr(ctx.graph, body, 'instanceName') || '';
    return {
      title: title,
      instanceName: instanceName,
      pins: []
    };
  }

  function resolveBody(cell) {
    var cur = cell;
    var i = 0;
    while (cur && i < 4) {
      if (readStyleValue(cur, 'dftsIP_type')) { return cur; }
      cur = cur.parent || null;
      i += 1;
    }
    return cell || null;
  }

  function buildContext(graph, cell) {
    var body = resolveBody(cell);
    return {
      graph: graph,
      body: body,
      dftsType: readStyleValue(body, 'dftsIP_type') || '',
      category: readStyleValue(body, 'dftsIP_category') || '',
      configKey: readStyleValue(body, 'dftsIP_configKey') || '',
      defKey: readStyleValue(body, 'dftsIP_defKey') || ''
    };
  }

  function buildState(ctx) {
    var body = ctx.body;
    var graph = ctx.graph;
    var attrs = {
      bodyLabel: readAttr(graph, body, 'bodyLabel') || readStyleValue(body, 'dftsIP_bodyLabel') || '',
      instanceName: readAttr(graph, body, 'instanceName') || '',
      busWidth: readAttr(graph, body, 'busWidth') || '',
      pdg: readAttr(graph, body, 'pdg') || '',
      pinLabel: readAttr(graph, body, 'pinLabel') || '',
      role: readAttr(graph, body, 'role') || '',
      sourceType: readAttr(graph, body, 'sourceType') || '',
      patternSet: readAttr(graph, body, 'patternSet') || ''
    };
    var symbolModel = null;
    var encoded = readStyleValue(body, 'dftsIP_symbolModel');
    if (body && body.__dftsSymbolModel) {
      symbolModel = cloneDeep(body.__dftsSymbolModel);
    }
    if (!symbolModel && encoded) {
      symbolModel = tryParseJson(decodeURIComponent(encoded), null) || tryParseJson(encoded, null);
    }
    if (!symbolModel) {
      symbolModel = guessDefaultSymbolModel(body, ctx);
    }
    return {
      attrs: attrs,
      symbolModel: cloneDeep(symbolModel),
      runtime: {}
    };
  }

  NS.State = {
    parseStyleMap: parseStyleMap,
    encodeStyleMap: encodeStyleMap,
    readStyleValue: readStyleValue,
    writeStyleValue: writeStyleValue,
    readAttr: readAttr,
    writeAttr: writeAttr,
    tryParseJson: tryParseJson,
    resolveBody: resolveBody,
    buildContext: buildContext,
    buildState: buildState,
    cloneDeep: cloneDeep
  };
})(this);
