# 09 — fixed_and_placed

## Purpose
Placement status: one FIXED + three PLACED with different orientations. Validate placement status (if exposed).

## Files
- `tech.lef`
- `lib.lef`
- `design.def`
- `expected.json`
- `README.md`

## Test Steps
> 目标：把 LEF/DEF 导入 OpenDB，然后用你们新增的 Traverser API 遍历并抽取 masters/instances（以及可选 regions/blockages/pins），并与 `expected.json` / 原始文件进行对比。

### Step 1 — Import into OpenDB
任选一种方式（建议用你们的封装 Importer；如果需要也可以直接调用 OpenDB 的 lefin/defin）。

**方式 A：用你们的封装（推荐）**
1. 调用 `Importer::LoadLefDef(...)`：
   - `lef_files` 按顺序传入：`tech.lef` → `lib*.lef`
   - `def_file`：`design.def`
2. ImportOptions 建议：
   - `skip_wires=true`
   - `skip_connections=true`
   - （若你们实现了更多 skip 项，也可以打开）

**方式 B：直接使用 OpenDB（仅供调试/对照）**
1. `lefin.createTechAndLib(...)` / `updateTechAndLib(...)` 导入 LEF；
2. `defin.skipWires(); defin.skipConnections(); defin.readChip(..., "design.def", chip, ...);`

### Step 2 — Traverse and Extract
1. `Traverser t(design_handle);`
2. `t.ForEachMaster(...)`：构建 `MasterTable`（name → width/height）
3. `t.ForEachInstance(..., compute_bbox=true)`：构建 `InstanceTable`（inst → master/origin/orient/bbox）
4. （可选）若你们实现了更多遍历 API：
   - `ForEachRegion(...)`、`ForEachBlockage(...)`、`ForEachTopPort(...)`

### Step 3 — Verify
1. 将抽取结果与 `expected.json` 比对（机器可读）；
2. 同时抽查 `design.def` 与 `lib*.lef` 的原始信息是否一致（人工可读）。

**最低要求断言**
- masters/instances 数量与名称正确
- 每个 instance 引用的 master 存在
- instance 的 (x,y)、orient 与 DEF 一致
- bbox 与 master 尺寸 + orient 变换一致
- 若含 REGIONS/BLOCKAGES/PINS：解析数量与坐标一致

---

## Notes
- 本 testcase 数据量非常小，适合做 CI 的快速回归。
- 若你们发现 parser 对最小 LEF/DEF 语法有额外要求，可以在不改变语义的前提下补齐（例如补 `UNITS` 或增加必要字段）。
